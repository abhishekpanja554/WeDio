package com.example.WEdio

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
